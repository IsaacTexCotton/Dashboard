# CAIXA FUTURO — Fase 1 (incremento local)

Esta entrega prepara uma implementação de baixo risco sobre o importador existente. Ela **não** consulta o CRM por conta própria durante os testes e não altera o repositório remoto.

## Alterações

- Validação estrutural do JSON antes de qualquer escrita, incluindo período, grupos esperados, identificadores de usuário, campos financeiros obrigatórios, números finitos e quantidades inteiras.
- Rejeição explícita de grupos ausentes, campos essenciais ausentes, usuários duplicados no mesmo grupo e períodos divergentes. Isso evita que uma resposta incompleta seja interpretada como um dia válido e apague dados anteriormente importados.
- Gravação de cada dia numa única transação SQLite; em caso de erro, a exclusão/substituição e o log de importação do dia são revertidos.
- Novo modo `--dry-run`, que exige `--arquivo`, valida a amostra e informa quantas linhas seriam importadas sem abrir/criar o banco de dados nem consultar a API.
- Uso explícito de GET e montagem robusta dos parâmetros de data sem duplicar `inicio` e `fim` existentes na URL.
- Validação de intervalo de datas e mensagens de erro sem incluir tokens/cookies.
- Testes automatizados com JSON local, incluindo rollback transacional e garantia de que `--dry-run` não cria banco.

## Como testar localmente

Requer Python 3.10+ (por causa das anotações de tipo usadas no arquivo).

```bash
python -m unittest discover -s tests -v
python importar.py --arquivo amostra_resposta.json --dry-run
```

O resultado do `dry-run` esperado é um resumo com 2 usuários e 5 fatos, separado em 2 depósitos, 1 acordo, 1 promessa e 1 contato. Os valores do JSON são ilustrativos.

## Importação local de arquivo

Só executar uma gravação após revisar a amostra e apontar `DASHBOARD_DB` para um caminho de teste, nunca diretamente para o banco de produção:

```bash
DASHBOARD_DB=./teste_cobranca.db python importar.py --arquivo amostra_resposta.json
```

Essa execução **grava** o arquivo no SQLite indicado. Não é necessária para validar o incremento; o conjunto de testes não executa a importação contra um banco persistente.

## Limites ainda em aberto

1. As colunas monetárias continuam como `REAL` para preservar compatibilidade do esquema atual. A migração para centavos inteiros/decimal deve ser uma etapa independente, com comparação de resultados.
2. Não há ainda uma decisão sobre se `acordos_posicao` é uma série de snapshots (a chave atual `capturado_em`) ou uma posição única por data de referência.
3. A validação requer campos presentes no contrato observado. Antes de produção, o payload precisa ser comparado com uma amostra real autorizada e sanitizada. A amostra incluída é fictícia.
4. Não foram adicionados testes de integração, não foi executado importador contra CRM e não foi feita migração de banco.
5. O acesso de escrita à integração GitHub recusou criação de branch com HTTP 403. Portanto, esses arquivos estão num pacote local e ainda precisam ser aplicados numa branch autorizada do repositório `IsaacTexCotton/Dashboard`.

## Próximo gate antes de produção

- Revisar o diff com o mantenedor;
- validar contrato com payload real sanitizado, sem expor dados de clientes;
- executar testes em SQLite temporário;
- aprovar a política de precisão monetária e snapshots;
- só então realizar integração controlada e planejar rollout.
